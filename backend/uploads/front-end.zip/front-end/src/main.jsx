import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.jsx'
// import './index.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import {
  createBrowserRouter,
  createRoutesFromElements,
  RouterProvider,
  Route,
} from "react-router-dom";
import NavComponent from './components/NavComponent.jsx';
import HomeScreen from './Screens/HomeScreen.jsx';
import RegisterForm from './Forms/RegisterForm.jsx';
import RegisterTable from './Tables/RegisterTable.jsx';
import PaymentForm from './Forms/PaymentForm.jsx';
import PaymentTable from './Tables/PaymentTable.jsx';
import PaymentReport from './Forms/PaymentReport.jsx';

const router =
  createBrowserRouter(
    createRoutesFromElements(
      <Route path='/' element={<App />}>
        <Route index={true} path='/' element={<HomeScreen />} />
        <Route path='/register' element={<RegisterForm />} />
        <Route path='/reg-table' element={<RegisterTable />} />
        <Route path="/update/:registerId" element={<RegisterForm />} />
        <Route path="/payment/create" element={<PaymentForm />} />
        <Route path="/payment/details" element={<PaymentTable />} />
        <Route path="/payment/report" element={<PaymentReport />} />
        <Route path="/payment/update/:paymentId" element={<PaymentForm />} />
      </Route>
    )

  )

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
)
