import React from 'react'
// import RegisterPage from './Pages/RegisterPage'
import NavComponent from './components/NavComponent'
// import RegisterForm from './Forms/RegisterForm'
import { Toaster } from 'react-hot-toast'
import { Outlet } from 'react-router-dom'
import './App.css'
const App = () => {
  return (
    <>
      <NavComponent />

      <Toaster />
    </>
  )
}

export default App