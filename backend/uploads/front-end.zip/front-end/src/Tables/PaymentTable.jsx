import React, { useEffect, useState } from 'react';
import { Table, Button as AntdBtn, Space } from 'antd';
import { EyeFilled, CloseCircleFilled, FileExcelOutlined, FilePdfOutlined, CopyOutlined } from '@ant-design/icons';
import { Input } from 'antd';
const { Search } = Input;
import axios from 'axios';
import toast from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';
import './PaymentTable.css';
import { Tooltip, Typography, Button, Paper, Stack, useMediaQuery } from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import FlagIcon from '@mui/icons-material/Flag';
import { Container } from 'react-bootstrap';

const PaymentTable = () => {

    const isSmallScreen = useMediaQuery('(max-width:600px)')
    const [payments, setPayments] = useState([]);

    const [filteredpayments, setFilteredpayments] = useState([]);

    const url = 'http://127.0.0.1:3000';
    const navigate = useNavigate();

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get(`${url}/payments`);
                setPayments(response.data);
                setFilteredpayments(response.data);
            } catch (error) {
                console.error(error);
            }
        };
        fetchData();
    }, []);


    const handleEdit = (paymentId) => {
        navigate(`/payment/update/${paymentId}`);
    };

    const handleDelete = async (paymentId) => {
        try {
            await axios.delete(`${url}/payments/${paymentId}`);
            setPayments(prevpayments => prevpayments.filter(payment => payment.pay_id !== paymentId));
            setFilteredpayments(prevpayments => prevpayments.filter(payment => payment.pay_id !== paymentId));
            toast.success('Deleted Successfully!')

        } catch (error) {
            console.error(error);
        }
    };

    const columns = [
        {
            title: 'Action',
            key: 'action',
            render: (text, record) => (
                <Space size="middle">
                    <Tooltip title={<Typography style={{ fontSize: 14 }}>Update Data</Typography>} placement='left-start'>
                        <EyeFilled onClick={() => handleEdit(record.pay_id)} style={{ cursor: 'pointer', fontSize: 23 }} />
                    </Tooltip>
                    <Tooltip title={<Typography style={{ fontSize: 14 }}>Delete Data</Typography>} placement='right-start'>
                        <CloseCircleFilled onClick={(e) => {
                            e.stopPropagation();
                            handleDelete(record.pay_id);
                        }} style={{ cursor: 'pointer', color: '#ff0000', fontSize: 20 }} />
                    </Tooltip>
                </Space>
            ),
            responsive: ['xs', 'sm', 'md', 'lg'],

        },
        {
            title: 'Payment ID',
            dataIndex: 'pay_id',
            key: 'pay_id',
            sorter: (a, b) => a.pay_id - b.pay_id,
            render: (text, record, index) => index + 1,
            responsive: ['xs', 'sm', 'md', 'lg'],

        },
        {
            title: 'Member Name',
            dataIndex: 'pay_name',
            key: 'pay_name',
            responsive: ['xs', 'sm', 'md', 'lg'],

        },
        {
            title: 'amount',
            dataIndex: 'pay_amount',
            key: 'pay_amount',
            responsive: ['xs', 'sm', 'md', 'lg'],
        },
        {
            title: 'paymentation Date',
            dataIndex: 'pay_date',
            key: 'pay_date',
            render: (text) => new Date(text).toLocaleDateString(), // formatting date
            responsive: ['xs', 'sm', 'md', 'lg'],
        }
    ];


    const onSearch = (value) => {
        const filteredData = payments.filter((payment) =>
            payment.pay_name.toLowerCase().includes(value.toLowerCase())
        );
        setFilteredpayments(filteredData);
    };

    const [currentPage, setCurrentPage] = useState(1);
    const pageSize = 7;

    const handleTableChange = (pagination) => {
        setCurrentPage(pagination.current);
    };

    const start = (currentPage - 1) * pageSize + 1;
    const end = Math.min(currentPage * pageSize, filteredpayments.length);

    return (
        <>
            <Container fluid className='payment-tb-container'>
                <Paper elevation={4} sx={{ borderRadius: 3 }} className='paymentPaper mt-5'>
                    <div className="d-flex justify-content-between mb-5">
                        <h4 className='p-3 fw-bold'>Payment Details</h4>
                        <Stack direction={isSmallScreen ? 'column' : 'row'} spacing={2} padding='10px 10px' alignItems="end">
                            <Button
                                variant='contained'
                                size='middle'
                                className='me-3'
                                color='success'
                                startIcon={<AddCircleIcon />}
                                onClick={() => {
                                    navigate('/payment/create')
                                }}
                            >
                                Add New
                            </Button>
                            <Button
                                variant='contained'
                                size='middle'
                                className='me-3'
                                color='info'
                                startIcon={<FlagIcon />}
                                onClick={() => {
                                    navigate('/payment/report')
                                }}
                            >
                                Paid Report
                            </Button>
                        </Stack>
                    </div>
                    <div className='main mx-auto'>
                        <div className="button-container">
                            <div>
                                <Search
                                    placeholder="search here"
                                    onSearch={onSearch}
                                    style={{
                                        width: 220,
                                        margin: '0 40px',
                                        transform: 'scale(1.3)',
                                    }}
                                />
                            </div>
                        </div>
                        <Table
                            columns={columns}
                            className="table-fetcher"
                            dataSource={filteredpayments}
                            rowKey="std_id"
                            onRow={(record) => {
                                return {
                                    onClick: () => handleEdit(record.pay_id),
                                };
                            }}
                            pagination={{
                                showSizeChanger: true
                            }}
                            sortDirections={['ascend', 'descend']}
                            scroll={{ x: true }}
                            rowClassName={(record, index) => (index % 2 === 0 ? 'striped-row-even' : 'striped-row-odd')}
                        />
                    </div>
                </Paper>
            </Container>
        </>
    );
};

export default PaymentTable;
