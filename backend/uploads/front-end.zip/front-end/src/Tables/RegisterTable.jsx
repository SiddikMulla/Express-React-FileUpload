import React, { useEffect, useState } from 'react';
import { Table, Button as AntdBtn, Space } from 'antd';
import { EyeFilled, CloseCircleFilled, FileExcelOutlined, FilePdfOutlined, CopyOutlined } from '@ant-design/icons';
import { Input } from 'antd';
const { Search } = Input;
import axios from 'axios';
import toast from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';
import './RegisterTable.css';
import { Tooltip, Typography, Button, Paper } from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import { WhatsAppOutlined } from '@ant-design/icons';

// const secretKey = 'sid123';

const RegisterTable = () => {
  const [registerations, setRegisterations] = useState([]);

  const [filteredregisterations, setFilteredregisterations] = useState([]);

  const url = 'http://127.0.0.1:3000';
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(`${url}/registerations`);
        setRegisterations(response.data);
        setFilteredregisterations(response.data);
      } catch (error) {
        console.error(error);
      }
    };
    fetchData();
  }, []);

  /* const exportToExcel = () => {
      const worksheet = XLSX.utils.json_to_sheet(filteredregisterations);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "registerations");
      XLSX.writeFile(workbook, "registerationsData.xlsx");
  };

  const exportToPDF = () => {
      const doc = new jsPDF();
      const tableColumn = ["Sr No.", "Name", "Email", "Description"];
      const tableRows = filteredregisterations.map((register, index) => [
          index + 1,
          register.std_name,
          register.std_email,
          register.std_descr,
      ]);

      autoTable(doc, {
          head: [tableColumn],
          body: tableRows,
      });

      doc.save("registerationsData.pdf");
  };

  const copyToClipboard = () => {
      const copyText = filteredregisterations.map(s => `${s.std_id}\t${s.std_name}\t${s.std_email}\t${s.std_descr}`).join('\n');
      navigator.clipboard.writeText(copyText)
          .then(() => toast.success('Copied to Clipboard', {
              style: {
                  borderRadius: '10px',
                  background: '#333',
                  color: '#fff',
              },
          }))
          .catch(err => console.error('Error copying text: ', err));
  };*/

  const handleEdit = (registerId) => {
    navigate(`/update/${registerId}`);
  };

  const handleDelete = async (registerId) => {
    try {
      await axios.delete(`${url}/registerations/${registerId}`);
      setRegisterations(prevregisterations => prevregisterations.filter(register => register.reg_id !== registerId));
      setFilteredregisterations(prevregisterations => prevregisterations.filter(register => register.reg_id !== registerId));
      toast.success('Deleted Successfully!')

    } catch (error) {
      console.error(error);
    }
  };

  const columns = [
    {
      title: 'Action',
      key: 'action',
      render: (text, record) => (
        <Space size="middle">
          <Tooltip title={<Typography style={{ fontSize: 14 }}>Update Data</Typography>} placement='left-start'>
            <EyeFilled
              onClick={(e) => {
                e.stopPropagation();
                handleEdit(record.reg_id);
              }}
              style={{ cursor: 'pointer', fontSize: 20 }}
            />
          </Tooltip>
          <Tooltip title={<Typography style={{ fontSize: 14 }}>Delete Data</Typography>} placement='right-start'>
            <CloseCircleFilled
              onClick={(e) => {
                e.stopPropagation();
                handleDelete(record.reg_id);
              }}
              style={{ cursor: 'pointer', color: '#ff0000', fontSize: 18 }}
            />
          </Tooltip>
        </Space>
      ),
      responsive: ['lg'],
    },

    {
      title: 'Register ID',
      dataIndex: 'reg_id',
      key: 'reg_id',
      render: (text, record, index) => index + 1,
      responsive: ['xs', 'sm', 'md', 'lg'],
    },
    {
      title: 'Member Name',
      dataIndex: 'reg_name',
      key: 'reg_name',
      responsive: ['xs', 'sm', 'md', 'lg'],
    },
    {
      title: 'Date of Birth',
      dataIndex: 'reg_dob',
      key: 'reg_dob',
      render: (text) => new Date(text).toLocaleDateString(),
      responsive: ['md', 'lg'],
    },
    {
      title: 'Registration Date',
      dataIndex: 'reg_date',
      key: 'reg_date',
      render: (text) => new Date(text).toLocaleDateString(),
      responsive: ['xs', 'sm', 'md', 'lg'],
    },
    {
      title: 'Mobile No.',
      dataIndex: 'reg_mob',
      key: 'reg_mob',
      responsive: ['md', 'lg'],
    },
    {
      title: 'Whatsapp',
      dataIndex: 'reg_mob',
      key: 'whatsapp',
      responsive: ['md', 'lg'],
      width:'130px',
      render: (text) => (
        <a
          href={`https://wa.me/${text}`}
          target="_blank"
          rel="noopener noreferrer"
        >
          <WhatsAppOutlined style={{ color: '#009e3a', fontWeight: 'bold',transform:'scale(1.3)' }} />
        </a>
      ),
    },
  ];


  const onSearch = (value) => {
    const filteredData = registerations.filter((register) =>
      register.reg_name.toLowerCase().includes(value.toLowerCase())
    );
    setFilteredregisterations(filteredData);
  };

  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 7;

  const handleTableChange = (pagination) => {
    setCurrentPage(pagination.current);
  };

  const start = (currentPage - 1) * pageSize + 1;
  const end = Math.min(currentPage * pageSize, filteredregisterations.length);

  return (
    <>
      <Paper elevation={5} sx={{ borderRadius: 1 }} className='tablePaper mt-5'>
        <div className='d-flex p-3 justify-content-between'>
          <h4 className='ms-2 fw-bold'>Register Details</h4>
          <Button
            variant='contained'
            size='small'
            className='me-3'
            startIcon={<AddCircleIcon />}
            onClick={() => {
              navigate('/register')
            }}
          >
            Add New
          </Button>
        </div>
        <div className='main mx-auto'>
          <div className="button-container">
            <div>
              <Search
                placeholder="search here"
                onSearch={onSearch}
                style={{
                  width: 200
                }}
              />
            </div>
          </div>
          <Table
            columns={columns}
            className="table-fetcher"
            dataSource={filteredregisterations}
            rowKey="std_id"
            onRow={(record) => {
              return {
                onClick: () => handleEdit(record.reg_id),
              };
            }}
            pagination={{
              showSizeChanger: true
            }}
            // scroll={{ x: true }}
            rowClassName={(record, index) => (index % 2 === 0 ? 'striped-row-even' : 'striped-row-odd')}
          />
        </div>
      </Paper>
    </>
  );
};

export default RegisterTable;
