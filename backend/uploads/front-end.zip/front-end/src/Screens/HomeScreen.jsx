import React from 'react';
import { Card, Container } from 'react-bootstrap';
import { Box, Divider, Paper } from '@mui/material';
import { Col, Row } from 'antd';
import './Home.css'
import { LinkContainer } from 'react-router-bootstrap'
const HomeScreen = () => {

  const cardData = [
    { title: 'Member Registration', path: '/register' },
    { title: 'Member Payment', path: '/payment/create' },
    { title: 'Payment List', path: '/payment/details' },
    { title: 'List', path: '/reg-table' },
    { title: 'Report', path: '/payment/report' },
    { title: 'Logout',path:'/logout' },
  ];

  return (
    <>
      <Container className='mt-5 d-flex justify-content-center'>
        <Paper
          elevation={12}
          sx={{
            width: {
              xs: '100%',
              sm: '100%',
              md: '90%',
              lg: '90%',
              xl: '90%',
            },
            backgroundColor: '#3f9cff',
            color: '#fff',
            padding: 2,
          }}
        >
          <h3 className='text-center mt-3'></h3>
          <Box
            sx={{
              margin: {
                xs: 2,
                sm: 3,
                md: 4,
                lg: 5,LinkContainer
              },
              backgroundColor: '#ffffff',
              borderRadius: '30px 30px 0 0',
              padding: {
                xs: 4,
                sm: 3,
                md: 4,
                lg: 5,
              },
            }}
          >
            <h2 className='text-center text-dark'>Daily Update</h2>
          </Box>
        </Paper>
      </Container>

      <Container>
        <Box
          sx={{
            margin: {
              xs: 1,
              sm: 3,
              md: 4,
              lg: 5,
            },
            borderRadius: '30px 30px 0 0',
            padding: {
              xs: 2,
              sm: 3,
              md: 4,
              lg: 5,
            },
          }}
        >
          <Row gutter={[32, 32]}>
            {cardData.map((item, index) => (
              <Col key={index} xl={8} xs={24}>
                <LinkContainer to={item.path}>
                  <Card className='text-center homeCard p-4'>

                    <Card.Title>
                      <h4>{item.title}</h4>
                    </Card.Title>
                  </Card>
                </LinkContainer>
              </Col>
            ))}
          </Row>
        </Box>
      </Container>
    </>
  );
};

export default HomeScreen;
