import React, { useState } from 'react'
import { useAuth } from '../context/auth';
import { useNavigate } from 'react-router-dom';
import { Container } from 'react-bootstrap';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import './Login.css'
import { Box, Button, FormControl, IconButton, InputAdornment, InputLabel, TextField } from '@mui/material';

const LoginPage = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const { login } = useAuth();
    const navigate = useNavigate();

    const [showPassword, setShowPassword] = useState(false);

    const handleClickShowPassword = () => setShowPassword((show) => !show);
    const handleMouseDownPassword = (event) => event.preventDefault();

    const handleSubmit = (e) => {
        e.preventDefault();
        if (login(username, password)) {
            toast.success('Login successful!');
            navigate('/');
        } else {
            toast.error('Incorrect username or password!');
        }
    };
    return (
        <>
            <Container className='d-flex justify-content-center'>
                <Box
                    component="form"
                    className='loginField'
                    onSubmit={handleSubmit}
                    sx={{ mt: 1, display: 'flex', flexDirection: 'column' }}>
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        label="Username"
                        value={username}
                        color='success'
                        InputLabelProps={{ shrink: true }}
                        onChange={(e) => setUsername(e.target.value)}
                    />
                    <FormControl variant="outlined" fullWidth margin="normal">
                        <InputLabel htmlFor="outlined-adornment-password"></InputLabel>
                        <TextField
                            id="outlined-adornment-password"
                            required
                            type={showPassword ? 'text' : 'password'}
                            value={password}
                            color='success'
                            onChange={(e) => setPassword(e.target.value)}
                            endAdornment={
                                <InputAdornment position="end">
                                    <IconButton
                                        aria-label="toggle password visibility"
                                        onClick={handleClickShowPassword}
                                        onMouseDown={handleMouseDownPassword}
                                        edge="end"
                                    >
                                        {showPassword ? <VisibilityOff /> : <Visibility />}
                                    </IconButton>
                                </InputAdornment>
                            }
                            label="Password"
                            InputLabelProps={{ shrink: true }}
                        />
                    </FormControl>
                    <Button
                        type="submit"
                        variant="contained"
                        color="primary"
                        sx={{ mt: 1, mb: 2, }}
                        className='align-self-center'
                    >
                        Login
                    </Button>
                </Box>
            </Container>
        </>
    )
}

export default LoginPage