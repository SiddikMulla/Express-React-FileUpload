import { Autocomplete, Box, Button, Divider, Paper, Stack, TextField } from '@mui/material';
import { Col, Row, Table } from 'antd';
import axios from 'axios';
import React, { useEffect, useState } from 'react';
import WalletIcon from '@mui/icons-material/Wallet';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import DisabledByDefaultIcon from '@mui/icons-material/DisabledByDefault';
import { useNavigate } from 'react-router-dom';
import { Container } from 'react-bootstrap';
import './PaymentReport.css'


const PaymentReport = () => {
    const [options, setOptions] = useState([]);
    const [payData, setPayData] = useState({
        pay_name: '',
        selectedMonth: new Date().toISOString().slice(0, 7)
    });
    const [successPay, setSuccessPay] = useState([]);
    const url = 'http://127.0.0.1:3000';
    const navigate = useNavigate();

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get(`${url}/registerations`);
                const data = response.data;
                const formattedOptions = data.map(item => ({
                    value: item.reg_id,
                    label: item.reg_name
                }));
                setOptions(formattedOptions);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };
        fetchData();
    }, []);

    const fetchFilteredPayments = async () => {
        try {
            const response = await axios.get(`${url}/payments`);
            const paidData = response.data;

            const filteredData = paidData.filter(item => {
                const isMonthMatch = item.pay_date.includes(payData.selectedMonth);
                const isNameMatch = payData.pay_name ? item.pay_name === payData.pay_name : true;
                return isMonthMatch && isNameMatch && item.pay_amount > 0;
            });

            setSuccessPay(filteredData);
        } catch (error) {
            console.error('Error fetching payment data:', error);
        }
    };

    useEffect(() => {
        fetchFilteredPayments();
    }, [payData]);

    const handleSuccess = () => {
        fetchFilteredPayments();
    };

    const handleUnsuccess = async () => {
        try {
            const payResponse = await axios.get(`${url}/payments`);
            const regResponse = await axios.get(`${url}/registerations`);
            const paidData = payResponse.data;
            const regData = regResponse.data;

            const unSuccess = regData.filter(reg => {

                const isUnsuccessful = !paidData.some(payment =>
                    payment.pay_name === reg.reg_name &&
                    payment.pay_date.includes(payData.selectedMonth)
                );

                const isNameMatch = payData.pay_name ? reg.reg_name === payData.pay_name : true;
                return isUnsuccessful && isNameMatch;
            });

            if (unSuccess.length > 0) {
                const filteredUnsuccess = unSuccess.map(reg => ({
                    pay_id: reg.reg_id,
                    pay_name: reg.reg_name,
                    pay_amount: 0,
                    pay_date: "Not Paid"
                }));
                setSuccessPay(filteredUnsuccess);
            } else {
                setSuccessPay([]);
            }
        } catch (error) {
            console.error('Error fetching unsuccessful payments:', error);
        }
    };

    const handleAutocompleteChange = (event, newValue) => {
        setPayData(prev => ({
            ...prev,
            pay_name: newValue ? newValue.label : ''
        }));
    };

    const handleMonthChange = (event) => {
        setPayData(prev => ({
            ...prev,
            selectedMonth: event.target.value
        }));
    };

    const columns = [
        {
            title: 'Payment ID',
            dataIndex: 'pay_id',
            key: 'pay_id',
            responsive: ['xs', 'sm', 'md', 'lg'],
        },
        {
            title: 'Member Name',
            dataIndex: 'pay_name',
            key: 'pay_name',
            responsive: ['xs', 'sm', 'md', 'lg'],
        },
        {
            title: 'Amount',
            dataIndex: 'pay_amount',
            key: 'pay_amount',
            responsive: ['xs', 'sm', 'md', 'lg'],
        },
        {
            title: 'Payment Date',
            dataIndex: 'pay_date',
            key: 'pay_date',
            responsive: ['xs', 'sm', 'md', 'lg'],
            render: (text) => text === "Not Paid" ? text : new Date(text).toLocaleDateString(),
        }
    ];

    return (
        <>
            <Container fluid className='pay-repo-container'>
                <Paper className='mt-5 rounded-3 payRepoPaper' elevation={4}>
                    <h3 className='text-center p-2'>Payment Report</h3>
                    <Divider sx={{ borderWidth: 1, borderColor: 'black' }} />
                    <Box sx={{ padding: 5, '& .MuiInputBase-root': { height: 47 } }}>
                        <Row gutter={[32, 32]} justify='center'>
                            <Col xl={5} lg={5} sm={24} xs={23}>
                                <TextField
                                    label='Select Month'
                                    type='month'
                                    value={payData.selectedMonth}
                                    InputLabelProps={{ shrink: true }}
                                    onChange={handleMonthChange}
                                    style={{ width: '100%' }}
                                />
                            </Col>
                            <Col xl={7} lg={7} sm={24} xs={23}>
                                <form>
                                    <Autocomplete
                                        options={options}
                                        getOptionLabel={(option) => option.label}
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                                label="Member Name"
                                                placeholder="Select a person"
                                                variant="outlined"
                                                fullWidth
                                                required
                                                InputLabelProps={{ shrink: true }}
                                                value={payData.pay_name}
                                                name='pay_name'
                                            />
                                        )}
                                        style={{ width: '100%' }}
                                        renderOption={(props, option) => (
                                            <li {...props} key={option.value}>
                                                {option.label}
                                            </li>
                                        )}
                                        onChange={handleAutocompleteChange}
                                    />
                                </form>
                            </Col>
                        </Row>
                    </Box>
                    <Stack direction="column" spacing={3} padding='30px 40px' alignItems="end">
                        <Button
                            variant='contained'
                            size='medium'
                            style={{ width: '150px' }}
                            color='success'
                            startIcon={<CheckBoxIcon />}
                            onClick={handleSuccess}
                        >
                            Success
                        </Button>
                        <Button
                            variant='contained'
                            size='medium'
                            style={{ width: '150px' }}
                            color='error'
                            startIcon={<DisabledByDefaultIcon />}
                            onClick={handleUnsuccess}
                        >
                            Unsuccess
                        </Button>
                        <Button
                            variant='contained'
                            size='medium'
                            color='info'
                            style={{ width: '150px' }}
                            onClick={() => (navigate('/payment/create'))}
                            startIcon={<WalletIcon />}
                        >
                            Payment
                        </Button>
                    </Stack>
                    <Table
                        columns={columns}
                        className="table-paymentRepo my-2 pb-5"
                        dataSource={successPay}
                        rowKey="pay_id"
                        scroll={{ x: true }}
                        pagination={{ showSizeChanger: true }}
                        rowClassName={(record, index) => (index % 2 === 0 ? 'striped-row-even' : 'striped-row-odd')}
                    />
                </Paper>
            </Container>
        </>
    );
};

export default PaymentReport;
