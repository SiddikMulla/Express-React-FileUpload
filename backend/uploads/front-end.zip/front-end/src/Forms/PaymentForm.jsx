import { Autocomplete, Box, Button, Divider, FormLabel, Modal, Paper, Stack, TextField, Typography, useMediaQuery } from '@mui/material';
import { Col, Form, Row, Select, Table } from 'antd';
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import AddBoxIcon from '@mui/icons-material/AddBox';
import SaveIcon from '@mui/icons-material/Save';
import DescriptionIcon from '@mui/icons-material/Description';
import CloseIcon from '@mui/icons-material/Close';
import toast from 'react-hot-toast';
import { useNavigate, useParams } from 'react-router-dom';
import FlagIcon from '@mui/icons-material/Flag';
import './PaymentForm.css'
import PersonAddAltIcon from '@mui/icons-material/PersonAddAlt';
import { Container } from 'react-bootstrap';

const today = new Date().toISOString().split('T')[0];
const PaymentForm = () => {
    const [options, setOptions] = useState([]);
    const url = 'http://127.0.0.1:3000';

    const { paymentId } = useParams();

    const [payData, setPayData] = useState({
        pay_name: '',
        pay_amount: '',
        pay_date: today
    })


    const isEditing = !!paymentId;

    useEffect(() => {
        if (isEditing) {
            const fetchMember = async () => {
                try {
                    const response = await axios.get(`http://127.0.0.1:3000/payments/${paymentId}`);
                    const fetchedData = response.data;
                    const formattedpayDate = fetchedData.pay_date ? new Date(fetchedData.pay_date).toISOString().split('T')[0] : today;
                    setPayData({
                        ...fetchedData,
                        pay_date: formattedpayDate
                    });
                } catch (error) {
                    toast.error('Error fetching Member data.');
                    console.error('Error fetching Member:', error);
                }
            };
            fetchMember();
        }
    }, [isEditing, paymentId]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get(`${url}/registerations`);
                const data = response.data;
                console.log(data)
                const formattedOptions = data.map(item => ({
                    value: item.reg_id,
                    label: item.reg_name,
                    mobile: item.reg_mob,
                }));
                setOptions(formattedOptions);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        fetchData();
    }, []);


    const [regData, setRegData] = useState({
        reg_name: '',
        reg_mob: '',
        reg_dob: '',
        reg_date: today
    });

    const [openMember, setOpenMember] = useState(false);

    const handleMemberOpen = () => {
        setOpenMember(true)
    }
    const handleMemberClose = () => {
        setOpenMember(false)
    }

    const handleSave = async () => {
        try {
            const dataToSave = {
                ...regData,
                reg_mob: Number(regData.reg_mob),
                reg_dob: new Date(regData.reg_dob).toISOString(),
                reg_date: new Date(regData.reg_date).toISOString()
            };

            if (!regData.reg_name || !regData.reg_dob || !regData.reg_mob) {
                toast.error('Please fill out all required fields.');
                return;
            }

            const response = await axios.post('http://127.0.0.1:3000/registerations', dataToSave);
            toast.success('Data saved successfully!');

            // Get the newly registered member
            const newMember = {
                value: response.data.reg_id,
                label: response.data.reg_name,
                mobile: response.data.reg_mob
            };

            setOptions(prevOptions => [
                ...prevOptions,
                newMember
            ]);


            setPayData(prevData => ({
                ...prevData,
                pay_name: newMember.label
            }));

            handleMemberClose();

        } catch (error) {
            console.error('Error in handleSave:', error.response ? error.response.data : error.message);
            toast.error('Error saving registration data.');
        }
    };


    const handleInputChange = (e) => {
        const { name, value } = e.target;

        if (name === 'reg_mob' && !/^\d*$/.test(value)) {
            return;
        }

        setRegData({ ...regData, [name]: value });
    };



    const handlePayInputChange = (e) => {
        const { name, value } = e.target;
        setPayData({ ...payData, [name]: value });
    };
    const isSmallScreen = useMediaQuery('(max-width:590px)')
    const style = {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: isSmallScreen ? 380 : 400,
        bgcolor: '#fff',
        borderRadius: 3,
        boxShadow: '1px 2px 30px #000000aa',
        pt: 2,
        px: 4,
        pb: 3,
    };

    const handlePaySave = async () => {
        try {
            const payDataSave = {
                ...payData,
                pay_date: new Date(payData.pay_date).toISOString(),
                pay_amount: parseFloat(payData.pay_amount)
            }

            if (isEditing) {
                await axios.put(`http://127.0.0.1:3000/payments/${paymentId}`, payDataSave);
                toast.success('Updated Successfully!');
            }
            else {
                if (!payData.pay_name || !payData.pay_amount || !payData.pay_date) {
                    toast.error('Please fill out all required fields.');
                    return;
                }
                await axios.post('http://127.0.0.1:3000/payments', payDataSave);
                toast.success('Data saved successfully!');
            }
        } catch (error) {

            if (!payData.pay_name || !payData.pay_amount || !payData.pay_date) {
                toast.error('Please fill out all required fields.');
                return;
            }
            console.error('Error in handleSave:', error.response ? error.response.data : error.message);
            toast.error('Error saving Payment data.');
        }
    }

    const navigate = useNavigate()

    const handlePayDescription = () => {
        navigate('/payment/details')
    }

    const [filterPayment, setFilterPayment] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');


    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get(`${url}/payments`)
                setFilterPayment(response.data)
            } catch (error) {
                console.log(error);
            }
        }
        fetchData();
    }, [])

    const handleAutocompleteChange = (event, newValue) => {
        setPayData(prev => ({
            ...prev,
            pay_name: newValue ? newValue.label : ''
        }));

        if (newValue) {
            setSearchTerm(newValue.label);
        } else {
            setSearchTerm('');
        }

    };

    const [filteredData, setFilteredData] = useState([]);

    useEffect(() => {
        if (searchTerm.trim() === '') {
            setFilteredData([]);
        } else {
            const filtered = filterPayment.filter(payment =>
                payment.pay_name.toLowerCase().includes(searchTerm.toLowerCase())
            );
            setFilteredData(filtered);
        }
    }, [searchTerm, filterPayment]);



    const columns = [
        {
            title: 'Payment ID',
            dataIndex: 'pay_id',
            key: 'pay_id',
            sorter: (a, b) => a.pay_id - b.pay_id,
            responsive: ['xs', 'sm', 'md', 'lg'],
        },
        {
            title: 'Amount',
            dataIndex: 'pay_amount',
            key: 'pay_amount',
            sorter: (a, b) => a.pay_amount - b.pay_amount,
            render: (amount) => `${amount.toFixed(2)}`,
            responsive: ['xs', 'sm', 'md', 'lg'],
        },
        {
            title: 'Payment Date',
            dataIndex: 'pay_date',
            key: 'pay_date',
            sorter: (a, b) => new Date(a.pay_date) - new Date(b.pay_date),
            render: (date) => new Date(date).toLocaleDateString(),
            responsive: ['xs', 'sm', 'md', 'lg'],
        },
    ];


    return (
        <>
            <Container className='payForm-container' fluid>
                <Paper
                    sx={{
                        padding: '12px 0',
                        borderRadius: 2.7,
                    }}
                    elevation={4}
                    className='mt-3 payPaper'
                >
                    <h3 className='text-center p-1'>Member Payment</h3>
                    <Divider sx={{ borderWidth: 1, borderColor: 'black' }} />

                    <Box sx={{
                        padding: '50px 30px', '& .MuiFormLabel-root': {
                            color: '#003590',
                            fontWeight: '600',
                            fontSize: 21,
                            backgroundColor: '#fff',
                        },
                    }}>
                        <Row gutter={[32, 32]} justify='center'>
                            <Col xs={20} xl={3}>
                                <Button
                                    variant='contained'
                                    size='large'
                                    className='p-3 w-100'
                                    startIcon={<PersonAddAltIcon style={{ margin: '0 5px' }} />}
                                    onClick={handleMemberOpen}
                                    style={{
                                        marginTop: -2
                                    }}
                                >
                                    Add Member
                                </Button>
                                <Modal
                                    open={openMember}
                                    onClose={handleMemberClose}
                                    aria-labelledby="child-modal-title"
                                    aria-describedby="child-modal-description"
                                >
                                    <Box sx={{
                                        ...style,

                                    }}>
                                        <div className='d-flex justify-content-between'>
                                            <h5 id="child-modal-title">New Member Registration</h5>
                                            <CloseIcon style={{
                                                fontSize: 35,
                                                marginTop: -5,
                                                '&:hover': {
                                                    color: 'primary.main',
                                                    transform: 'scale(1.1)',
                                                    transition: 'all 0.3s ease',
                                                },
                                                '&:focus': {
                                                    color: 'primary.main',
                                                    transform: 'scale(1.1)',
                                                    transition: 'all 0.3s ease',
                                                },
                                                '&:active': {
                                                    color: 'secondary.main',
                                                    transform: 'scale(1.1)',
                                                    transition: 'all 0.4s ease',
                                                },
                                            }} onClick={handleMemberClose}
                                            />
                                        </div>
                                        <Divider style={{
                                            border: '1px solid black'
                                        }} />

                                        <Row gutter={[32, 32]} className='mt-5'>
                                            <Col xl={24} md={24} sm={24} xs={24}>
                                                <TextField
                                                    label='Member Full Name'
                                                    required
                                                    InputLabelProps={{ shrink: true }}
                                                    style={{ width: '100%' }}
                                                    placeholder='Enter Member Name'
                                                    value={regData.reg_name}
                                                    onChange={handleInputChange}
                                                    name='reg_name'
                                                />
                                            </Col>
                                            <Col xl={24} md={24} sm={24} xs={24}>
                                                <TextField
                                                    label='Mobile No.'
                                                    type='tel'
                                                    InputLabelProps={{ shrink: true }}
                                                    style={{ width: '100%' }}
                                                    placeholder='Enter Mobile No.'
                                                    value={regData.reg_mob}
                                                    onChange={handleInputChange}
                                                    name='reg_mob'
                                                    inputProps={{ maxLength: 10 }}
                                                />
                                            </Col>
                                            <Col xl={24} md={24} sm={24} xs={24}>
                                                <TextField
                                                    label='Birth Date'
                                                    type='date'
                                                    InputLabelProps={{ shrink: true }}
                                                    style={{ width: '100%' }}
                                                    value={regData.reg_dob}
                                                    onChange={handleInputChange}
                                                    name='reg_dob'
                                                />
                                            </Col>
                                            <Col xl={24} md={24} sm={24} xs={24}>
                                                <TextField
                                                    label='Registration Date'
                                                    type='date'
                                                    InputLabelProps={{ shrink: true }}
                                                    InputProps={{ readOnly: true }}
                                                    style={{ width: '100%' }}
                                                    value={regData.reg_date || today}
                                                    onChange={handleInputChange}
                                                    name='reg_date'
                                                />
                                            </Col>
                                        </Row>
                                        <Stack direction='row' spacing={2} padding={3} justifyContent='end'>
                                            <Button variant='contained' onClick={handleSave}>Save</Button>
                                            <Button onClick={handleMemberClose} variant='contained' color='error'>Cancel</Button>
                                        </Stack>
                                    </Box>
                                </Modal>
                            </Col>
                            <Col xs={24} xl={6}>
                                <form>
                                    <Autocomplete
                                        options={options}
                                        getOptionLabel={(option) => option.label}
                                        value={options.find((opt) => opt.label === payData.pay_name) || null}
                                        onChange={handleAutocompleteChange}
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                                label="Member Name"
                                                placeholder="Select a person"
                                                variant="outlined"
                                                fullWidth
                                                required
                                                InputLabelProps={{ shrink: true }}
                                                name='pay_name'
                                            />
                                        )}
                                        style={{ width: '100%' }}
                                        renderOption={(props, option) => (
                                            <li {...props} key={option.value}>
                                                {`${option.label} (${option.mobile})`}
                                            </li>
                                        )}
                                    />
                                </form>
                            </Col>
                            <Col xs={24} xl={5}>
                                <TextField
                                    label='Amount'
                                    type='number'
                                    style={{ width: '100%' }}
                                    InputLabelProps={{ shrink: true }}
                                    value={payData.pay_amount}
                                    placeholder='Enter Amount'
                                    onChange={handlePayInputChange}
                                    name='pay_amount'
                                />
                            </Col>

                            <Col xs={24} xl={5}>
                                <TextField
                                    label='Payment Date'
                                    type='date'
                                    style={{ width: '100%' }}
                                    InputLabelProps={{ shrink: true }}
                                    value={payData.pay_date || today}
                                    onChange={handlePayInputChange}
                                    name='pay_date'
                                />
                            </Col>
                        </Row>
                        <Stack direction="row" spacing={2} padding='30px 20px' justifyContent="end">

                            <Button
                                variant='contained'
                                size={isSmallScreen ? 'small' : 'medium'}
                                startIcon={<SaveIcon fontSize='small' />}
                                onClick={handlePaySave}
                            >
                                Save
                            </Button>
                            <Button
                                variant='contained'
                                size={isSmallScreen ? 'small' : 'medium'}
                                color='success'
                                startIcon={<DescriptionIcon fontSize='small' />}
                                onClick={handlePayDescription}

                            >
                                Details
                            </Button>
                            <Button
                                variant='contained'
                                size={isSmallScreen ? 'small' : 'medium'}
                                color='info'
                                startIcon={<FlagIcon fontSize='small' />}
                                onClick={() => (navigate('/payment/report'))}
                            >
                                Report
                            </Button>
                        </Stack>
                        <Box
                            sx={{
                                maxHeight: '300px',
                                maxWidth: '100%',
                                marginTop: 3,
                            }}
                        >
                            <Table
                                columns={columns}
                                className="table-paymentRepo my-5"
                                dataSource={filteredData}
                                pagination={false}
                                rowKey="std_id"
                                scroll={true}
                                sortDirections={['ascend', 'descend']}
                                rowClassName={(record, index) => (index % 2 === 0 ? 'striped-row-even' : 'striped-row-odd')}
                            />

                        </Box>
                    </Box>
                </Paper>
            </Container>
        </>
    );
};

export default PaymentForm;
