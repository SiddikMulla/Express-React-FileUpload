import { Box, Button, Divider, Paper, Stack, TextField, Typography, useMediaQuery } from '@mui/material';
import React, { useEffect, useState } from 'react';
import { Container } from 'react-bootstrap';
import { Col, Row } from 'antd';
import SaveIcon from '@mui/icons-material/Save';
import DescriptionIcon from '@mui/icons-material/Description';
import axios from 'axios';
import './Register.css';
import toast from 'react-hot-toast';
import { useNavigate, useParams } from 'react-router-dom';

const today = new Date().toISOString().split('T')[0];

const RegisterForm = () => {

    const { registerId } = useParams();

    const [regData, setRegData] = useState({
        reg_name: '',
        reg_mob: '',
        reg_dob: '',
        reg_date: today 
    });

    const isSmallScreen = useMediaQuery('(max-width:530px)')

    const isEditing = !!registerId;

    useEffect(() => {
        if (isEditing) {
            const fetchMember = async () => {
                try {
                    const response = await axios.get(`http://127.0.0.1:3000/registerations/${registerId}`);
                    const fetchedData = response.data;

                    const formattedRegDob = fetchedData.reg_dob ? new Date(fetchedData.reg_dob).toISOString().split('T')[0] : '';
                    const formattedRegDate = fetchedData.reg_date ? new Date(fetchedData.reg_date).toISOString().split('T')[0] : today;

                    setRegData({
                        ...fetchedData,
                        reg_dob: formattedRegDob,
                        reg_date: formattedRegDate
                    });
                } catch (error) {
                    toast.error('Error fetching Member data.');
                    console.error('Error fetching Member:', error);
                }
            };
            fetchMember();
        }
    }, [isEditing, registerId]);

    const handleSave = async () => {
        try {
            if (!regData.reg_name || !regData.reg_dob || !regData.reg_mob) {
                toast.error('Please fill out all required fields.');
                return;
            }

            const dataToSave = {
                ...regData,
                reg_mob: Number(regData.reg_mob), 
                reg_dob: new Date(regData.reg_dob).toISOString(), 
                reg_date: new Date(regData.reg_date).toISOString() 
            };

            if (isEditing) {
                await axios.put(`http://127.0.0.1:3000/registerations/${registerId}`, dataToSave);
                toast.success('Updated Successfully!');
            } else {
                await axios.post('http://127.0.0.1:3000/registerations', dataToSave);
                toast.success('Data saved successfully!');
            }
        } catch (error) {
            console.error('Error in handleSave:', error.response ? error.response.data : error.message);
            toast.error('Error saving registration data.');
        }
    };


    const handleInputChange = (e) => {
        const { name, value } = e.target;

        if (name === 'reg_mob' && !/^\d*$/.test(value)) {
            return;
        }

        setRegData({ ...regData, [name]: value });
    };

    const navigate = useNavigate()

    const handleDescription = () => {
        navigate('/reg-table')
    };



    return (
        <Container fluid className='mt-5'>
            <Paper elevation={7} style={{ padding: '12px 0', borderRadius: 12 }} className='RegPaper'>
                <Typography variant={isSmallScreen ? "h6" : "h5"} className='text-center fw-bold'>
                    {isEditing ? 'Member Updation' : 'Member Registration'}
                </Typography>
                <Divider sx={{ borderWidth: 1, borderColor: 'black', margin: '10px 0' }} />
                <Box
                    component="form"
                    sx={{
                        '& .MuiTextField-root': { m: '0.1rem', width: '35ch' },
                        '& .MuiFormLabel-root': {
                            color: '#003590',
                            fontWeight: '600',
                            fontSize: 21,
                            backgroundColor: '#fff',
                        },
                        '& .MuiTypography-root': {
                            fontSize: 12,
                        },
                        padding: 4,
                    }}
                    noValidate
                    autoComplete="off"
                >
                    <Row gutter={[32, 32]}>
                        <Col xl={8} md={12} sm={24} xs={24}>
                            <TextField
                                label='Member Full Name'
                                required
                                InputLabelProps={{ shrink: true }}
                                style={{ width: '100%' }}
                                placeholder='Enter Member Name'
                                value={regData.reg_name}
                                onChange={handleInputChange}
                                name='reg_name'
                            />
                        </Col>
                        <Col xl={5} md={12} sm={24} xs={24}>
                            <TextField
                                label='Mobile No.'
                                type='tel'
                                InputLabelProps={{ shrink: true }}
                                style={{ width: '100%' }}
                                placeholder='Enter Mobile No.'
                                value={regData.reg_mob}
                                onChange={handleInputChange}
                                name='reg_mob'
                                inputProps={{ maxLength: 10 }}
                            />
                        </Col>
                        <Col xl={5} md={12} sm={24} xs={24}>
                            <TextField
                                label='Birth Date'
                                type='date'
                                InputLabelProps={{ shrink: true }}
                                style={{ width: '100%' }}
                                value={regData.reg_dob}
                                onChange={handleInputChange}
                                name='reg_dob'
                            />
                        </Col>
                        <Col xl={5} md={12} sm={24} xs={24}>
                            <TextField
                                label='Registration Date'
                                type='date'
                                InputLabelProps={{ shrink: true }}
                                InputProps={{ readOnly: true }}
                                style={{ width: '100%' }}
                                value={regData.reg_date || today}
                                onChange={handleInputChange}
                                name='reg_date'
                            />
                        </Col>
                    </Row>
                </Box>
                <Stack direction="row" spacing={2} padding='14px 20px' justifyContent="end">
                    <Button
                        variant='contained'
                        size='medium'
                        startIcon={<SaveIcon fontSize='small' />}
                        onClick={handleSave}
                    >
                        Save
                    </Button>
                    <Button
                        variant='contained'
                        size='medium'
                        color='success'
                        startIcon={<DescriptionIcon fontSize='small' />}
                        onClick={handleDescription}
                    >
                        Details
                    </Button>
                </Stack>
            </Paper>
        </Container>
    );
};

export default RegisterForm;
