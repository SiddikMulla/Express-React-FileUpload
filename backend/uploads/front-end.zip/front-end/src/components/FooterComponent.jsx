import { useMediaQuery } from '@mui/material';
import React from 'react'
import { Container } from 'react-bootstrap';

const FooterComponent = () => {
    const isSmallScreen = useMediaQuery('(max-width: 560px)');
    const isMediumScreen = useMediaQuery('(max-width: 1200px)');
    const isLgScreen = useMediaQuery('(max-width: 1300px)');

    const currentYear = new Date().getFullYear();

    return (
        <Container fluid className='d-flex justify-content-center align-items-center mt-5' style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
            <p className='text-muted' style={{
                textAlign: 'center',
                fontSize: isSmallScreen ? 14 : isMediumScreen ? 16 : isLgScreen ? 17 : 18,
                letterSpacing: '0.06rem',
                marginTop: 60,
            }}>
                Design and Developed by{' '} <br />
                <a
                    style={{
                        fontWeight: 'bold',
                        textDecoration: 'none',
                        color: '#a30000',
                        transition: 'color 0.3s ease, text-shadow 0.3s ease',
                        textShadow: '1px 1px 2px rgba(0, 0, 0, 0.1)'
                    }}
                    href="https://www.comtranse.in/"
                    target="_blank"
                    rel="noopener noreferrer"
                >
                    Comtranse Technology
                </a>, Kolhapur &copy;{currentYear}
            </p>
        </Container>
    );
}

export default FooterComponent