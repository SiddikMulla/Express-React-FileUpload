import React from 'react'

const TabComponent = () => {
    return (
        <>
        </>
    )
}

export default TabComponent