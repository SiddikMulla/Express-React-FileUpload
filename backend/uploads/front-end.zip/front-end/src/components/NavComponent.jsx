import Container from 'react-bootstrap/Container';
import Navbar from 'react-bootstrap/Navbar';
import comtranse from '../assets/comtranse.png';
import { useEffect, useRef, useState } from 'react';
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import './Nav.css';
import Button from '@mui/material/Button';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import HomeWorkOutlinedIcon from '@mui/icons-material/HomeWorkOutlined';
import AppRegistrationOutlinedIcon from '@mui/icons-material/AppRegistrationOutlined';
import PaymentOutlinedIcon from '@mui/icons-material/PaymentOutlined';
import FindInPageOutlinedIcon from '@mui/icons-material/FindInPageOutlined';
import LogoutIcon from '@mui/icons-material/Logout';
import FormatIndentIncreaseIcon from '@mui/icons-material/FormatIndentIncrease';
import FormatIndentDecreaseIcon from '@mui/icons-material/FormatIndentDecrease';
import { Divider, IconButton, Paper, Slide, Tooltip, Typography, useMediaQuery } from '@mui/material';
import { Link, Outlet } from 'react-router-dom';
import { LinkContainer } from 'react-router-bootstrap';
import CloseCircleFilled from '@ant-design/icons/CloseCircleFilled';
import DashboardIcon from '@mui/icons-material/Dashboard';
import HelpCenterIcon from '@mui/icons-material/HelpCenter';
import SyncProblemIcon from '@mui/icons-material/SyncProblem';
import FolderCopyIcon from '@mui/icons-material/FolderCopy';
import BusinessCenterIcon from '@mui/icons-material/BusinessCenter';
import BadgeIcon from '@mui/icons-material/Badge';
import EditNoteIcon from '@mui/icons-material/EditNote';
import RateReviewIcon from '@mui/icons-material/RateReview';
import AddCardIcon from '@mui/icons-material/AddCard';
import AccountBalanceIcon from '@mui/icons-material/AccountBalance';
import FooterComponent from './FooterComponent';

const drawerWidth = 80;

function NavComponent() {
    const isSmallScreen = useMediaQuery('(max-width:530px)')

    const [open, setOpen] = useState(isSmallScreen ? false : true);
    const [openSubMenu, setOpenSubMenu] = useState('');

    const toggleDrawer = () => {
        setOpen(!open);
        setOpenSubMenu(false);
    };

    const handleMenuClick = (menu) => {
        setOpenSubMenu(prevState => (prevState === menu ? '' : menu));
    };

    const handleCloseSubMenu = () => {
        setOpenSubMenu(false);
    };

    const menuItems = [
        { text: 'Home', icon: <HomeWorkOutlinedIcon />, menusub: '' },
        { text: 'Register', icon: <AppRegistrationOutlinedIcon />, menusub: 'register' },
        { text: 'Payment', icon: <PaymentOutlinedIcon />, menusub: 'payment' },
        { text: 'Report', icon: <FindInPageOutlinedIcon />, menusub: 'report' },
        { text: 'Logout', icon: <LogoutIcon />, menusub: '' },
    ];



    const DrawerList = (
        <Box sx={{ width: drawerWidth, marginTop: 1 }} role="presentation">
            <List>
                {menuItems.map((item) => (
                    <ListItem
                        key={item.text}
                        sx={{ marginTop: -1, overflowX: 'hidden' }}
                        disablePadding
                        onClick={() => handleMenuClick(item.menusub)}
                    >
                        <ListItemButton
                            component={item.text === 'Home' ? Link : 'button'}
                            to={item.text === 'Home' ? '/' : '#'}
                        >
                            <ListItemIcon style={{ transform: 'scale(1.8)', color: '#000000cc', margin: 18, padding: 1 }}>
                                <Tooltip title={<Typography>{item.text}</Typography>} placement="right">
                                    {item.icon}
                                </Tooltip>
                            </ListItemIcon>
                            <ListItemText
                                primary={item.text}
                                primaryTypographyProps={{
                                    style: { marginLeft: 10, flex: 1 },
                                }}
                            />
                        </ListItemButton>
                    </ListItem>
                ))}
            </List>
        </Box>
    );

    let menuRef = useRef();

    let listRef = useRef();

    useEffect(() => {
        const handler = (e) => {
            if (menuRef.current && !menuRef.current.contains(e.target)) {
                setOpenSubMenu(false);
            }
        };

        document.addEventListener('mousedown', handler);
        return () => document.removeEventListener('mousedown', handler);
    }, []);

   

    return (
        <Box sx={{ display: 'flex' }} >
            <Drawer
                variant="permanent"
                open={open}
                sx={{
                    width: open ? drawerWidth : 0,
                    flexShrink: 0,
                    '& .MuiDrawer-paper': {
                        width: open ? drawerWidth : 0,
                        boxSizing: 'border-box',
                        transform: 'translateY(66px)',
                        transition: 'width 0.3s ease-in-out',
                        boxShadow: openSubMenu ? '' : '8px 6px 10px #00000032'
                    },
                }}

            >
                {DrawerList}
            </Drawer>
            <div ref={menuRef} style={{ marginLeft: open ? drawerWidth : 0, transition: 'margin-left 0.3s' }}>
                {/* Submenus */}
                {openSubMenu && (
                    <Slide direction="right" in={Boolean(openSubMenu)} mountOnEnter unmountOnExit>
                        <Paper

                            elevation={24}
                            sx={{
                                width: '260px',
                                height: '98vh',
                                position: 'fixed',
                                top: 8, // Same top distance as the main drawer
                                left: drawerWidth,
                                zIndex: 100,
                                backgroundColor: '#ffffff',
                                paddingTop: 5,
                                paddingLeft: 1,
                                marginTop: 7
                            }}
                        >
                            <IconButton
                                sx={{ position: 'absolute', top: 8, right: 8, zIndex: 200 }}
                                onClick={handleCloseSubMenu}
                            >
                                <CloseCircleFilled style={{ fontSize: '30px' }} />
                            </IconButton>
                            <List component="div" disablePadding>
                                {openSubMenu === 'register' && (
                                    <>
                                        <ListItem button component={Link} to="/register">
                                            <ListItemIcon>
                                                <EditNoteIcon />
                                            </ListItemIcon>
                                            <ListItemText sx={{
                                                marginLeft: -3
                                            }} primary="New Registeration" />
                                        </ListItem>
                                        <Divider />
                                        <ListItem button component={Link} to="/reg-table">
                                            <ListItemIcon>
                                                <RateReviewIcon />
                                            </ListItemIcon>
                                            <ListItemText sx={{
                                                marginLeft: -3
                                            }} primary="Registeration Details" />
                                        </ListItem>
                                        <Divider />

                                    </>
                                )}
                                {openSubMenu === 'payment' && (
                                    <>
                                        <ListItem button component={Link} to='/payment/create'>
                                            <ListItemIcon>
                                                <AddCardIcon />
                                            </ListItemIcon>
                                            <ListItemText sx={{
                                                marginLeft: -3
                                            }} primary="New Payment" />
                                        </ListItem>
                                        <Divider />
                                        <ListItem button component={Link} to='/payment/details'>
                                            <ListItemIcon>
                                                <AccountBalanceIcon />
                                            </ListItemIcon>
                                            <ListItemText sx={{
                                                marginLeft: -3
                                            }} primary="payment Details" />
                                        </ListItem>
                                        <Divider />
                                    </>
                                )}
                                {openSubMenu === 'report' && (
                                    <>
                                        <ListItem button component={Link} to='/payment/report'>
                                            <ListItemIcon>
                                                <FolderCopyIcon />
                                            </ListItemIcon>
                                            <ListItemText sx={{
                                                marginLeft: -3
                                            }} primary="Payment Report" />
                                        </ListItem>
                                        <Divider />

                                    </>
                                )}
                            </List>
                        </Paper>
                    </Slide>
                )}
            </div>
            <Box
                sx={{
                    flexGrow: 1,
                    marginLeft: open ? -11 : '0px',
                    transition: 'margin-left 0.3s cubic-bezier(0.25, 0.1, 0.25, 1)',
                }}
            >
                <Navbar fixed="top" expand="lg" className="navComp">
                    <LinkContainer to='/'>
                        <Navbar.Brand>
                            <img
                                src={comtranse}
                                height="40px"
                                style={{ transform: 'scale(2.5)', marginLeft: 15 }}
                                alt="Logo"
                            />
                        </Navbar.Brand>
                    </LinkContainer>
                    <Button onClick={toggleDrawer} sx={{
                        transform: 'scale(1.5)',
                        color: '#006cbf'
                    }}>
                        {open ? <FormatIndentIncreaseIcon /> : <FormatIndentDecreaseIcon />}
                    </Button>
                </Navbar>
                <Box component="main" sx={{ marginTop: '56px', padding: 3 }}>
                    <Container fluid>
                        <Outlet />
                        <FooterComponent />
                    </Container>
                </Box>
            </Box>
        </Box>
    );
}

export default NavComponent;
